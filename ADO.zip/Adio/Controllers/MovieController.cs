﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Adio.Models;

namespace Adio.Controllers
{
    public class MovieController : Controller
    {
        private readonly string connectionString = "Data Source=DESKTOP-9D7FFGG;Initial Catalog=crudDB;Integrated Security=True";       
        [HttpGet]
            public ActionResult Index()
        {
            DataTable dtblMovie = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlDataAdapter dtab = new SqlDataAdapter("SELECT * FROM movielist", conn);
                dtab.Fill(dtblMovie);
            }
                return View(dtblMovie);
        }

        [HttpGet]
        // GET: Movie/Create
        public ActionResult Create()
        {
            return View(new MovieModel());
        }

        // POST: Movie/Create
        [HttpPost]
        public ActionResult Create(MovieModel movieModel)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO movielist VALUES(@MovieName,@ReleaseYear)";
                SqlCommand cmd = new SqlCommand(query, conn);   
                cmd.Parameters.AddWithValue("@MovieName", movieModel.MovieName);
                cmd.Parameters.AddWithValue("@ReleaseYear", movieModel.ReleaseYear);
                cmd.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

        // GET: Movie/Edit/5
        public ActionResult Edit(int id)
        {
            MovieModel movieModel = new MovieModel();
            DataTable dtblMovie = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM MovieList Where MovieID = @MovieID";
                SqlDataAdapter dtab = new SqlDataAdapter(query, conn);
                dtab.SelectCommand.Parameters.AddWithValue("@MovieID", id);
                dtab.Fill(dtblMovie);
            }
            if (dtblMovie.Rows.Count == 1)
            {
                movieModel.MovieID = Convert.ToInt32(dtblMovie.Rows[0][0]);
                movieModel.MovieName = (dtblMovie.Rows[0][1].ToString());
                movieModel.ReleaseYear = Convert.ToInt32(dtblMovie.Rows[0][2]);
                return View(movieModel);
            }
            else
                return RedirectToAction("Index");
        }
        // POST: Movie/Edit/5
        [HttpPost]
        public ActionResult Edit(MovieModel movieModel)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE movielist SET  MovieName=@MovieName, ReleaseYear = @ReleaseYear where MovieID = @MovieID ";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MovieID", movieModel.MovieID);
                cmd.Parameters.AddWithValue("@MovieName", movieModel.MovieName);
                cmd.Parameters.AddWithValue("@ReleaseYear", movieModel.ReleaseYear);
                cmd.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

        // GET: Movie/Delete/5
        public ActionResult Delete(int id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM movielist where MovieID = @MovieID ";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MovieID", id);
                cmd.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

      
    }
}
