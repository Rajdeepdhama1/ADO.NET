create database crudDB
CREATE TABLE MOVIELIST(
   MovieID   INT  IDENTITY  NOT NULL,
   MovieName VARCHAR (20)     NOT NULL,
   ReleaseYear INT,
   PRIMARY KEY (MovieID),
) 
select * from MOVIELIST
insert into MOVIELIST values('Avengers',2018)
